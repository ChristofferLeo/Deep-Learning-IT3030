# Plots
trian-loss
error given time


# Predictions 
one step at the time
full step
    -> Save the error and preds to file
        Repeat for every model


# For each model done
save
    - Preds
    - Error
    - Loss 
